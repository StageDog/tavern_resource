const config = {
  plugins: [require('autoprefixer'), require('postcss-nested')],
};

module.exports = config;
